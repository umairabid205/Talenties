# Talenties

A new Flutter project.

## Getting Started

MyFlutter projects are built to run on the Flutter _stable_ release.
