import '/my_flutter/my_flutter_util.dart';
import 'bottom_popup_menu_widget.dart' show BottomPopupMenuWidget;
import 'package:flutter/material.dart';

class BottomPopupMenuModel extends MyFlutterModel<BottomPopupMenuWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
