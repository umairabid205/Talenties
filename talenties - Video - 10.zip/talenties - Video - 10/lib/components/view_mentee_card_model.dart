import '/my_flutter/my_flutter_util.dart';
import 'view_mentee_card_widget.dart' show ViewMenteeCardWidget;
import 'package:flutter/material.dart';

class ViewMenteeCardModel extends MyFlutterModel<ViewMenteeCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
