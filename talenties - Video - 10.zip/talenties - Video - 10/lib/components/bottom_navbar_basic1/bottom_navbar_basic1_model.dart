import '/my_flutter/my_flutter_util.dart';
import 'bottom_navbar_basic1_widget.dart' show BottomNavbarBasic1Widget;
import 'package:flutter/material.dart';

class BottomNavbarBasic1Model extends MyFlutterModel<BottomNavbarBasic1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
