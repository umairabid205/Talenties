import '/my_flutter/my_flutter_util.dart';
import 'floating_button_basic1_widget.dart' show FloatingButtonBasic1Widget;
import 'package:flutter/material.dart';

class FloatingButtonBasic1Model
    extends MyFlutterModel<FloatingButtonBasic1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
