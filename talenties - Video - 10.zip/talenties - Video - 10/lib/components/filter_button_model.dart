import '/my_flutter/my_flutter_util.dart';
import 'filter_button_widget.dart' show FilterButtonWidget;
import 'package:flutter/material.dart';

class FilterButtonModel extends MyFlutterModel<FilterButtonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
