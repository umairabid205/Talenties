import '/my_flutter/my_flutter_util.dart';
import 'attendee_card_widget.dart' show AttendeeCardWidget;
import 'package:flutter/material.dart';

class AttendeeCardModel extends MyFlutterModel<AttendeeCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
