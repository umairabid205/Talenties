import '/my_flutter/my_flutter_util.dart';
import 'ticket_event_widget.dart' show TicketEventWidget;
import 'package:flutter/material.dart';

class TicketEventModel extends MyFlutterModel<TicketEventWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
