import '/my_flutter/my_flutter_util.dart';
import 'ban_page_widget.dart' show BanPageWidget;
import 'package:flutter/material.dart';

class BanPageModel extends MyFlutterModel<BanPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
