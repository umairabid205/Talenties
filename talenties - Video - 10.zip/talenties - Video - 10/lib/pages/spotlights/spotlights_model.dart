import '/my_flutter/my_flutter_util.dart';
import 'spotlights_widget.dart' show SpotlightsWidget;
import 'package:flutter/material.dart';

class SpotlightsModel extends MyFlutterModel<SpotlightsWidget> {
  ///  Local state fields for this page.

  bool? edit = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
