import '/my_flutter/my_flutter_util.dart';
import 'junk_widget.dart' show JunkWidget;
import 'package:flutter/material.dart';

class JunkModel extends MyFlutterModel<JunkWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
