import '/my_flutter/my_flutter_util.dart';
import 'booked_meeting_summery_widget.dart' show BookedMeetingSummeryWidget;
import 'package:flutter/material.dart';

class BookedMeetingSummeryModel
    extends MyFlutterModel<BookedMeetingSummeryWidget> {
  ///  Local state fields for this page.

  String? paymentMethod;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
